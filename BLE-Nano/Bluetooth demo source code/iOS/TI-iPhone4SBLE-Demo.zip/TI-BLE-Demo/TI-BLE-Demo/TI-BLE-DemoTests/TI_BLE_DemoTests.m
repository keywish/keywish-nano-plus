//
//  TI_BLE_DemoTests.m
//  TI-BLE-DemoTests
//
//  Created by Ole Andreas Torvmark on 10/29/11.
//  Copyright (c) 2011 ST alliance AS. All rights reserved.
//

#import "TI_BLE_DemoTests.h"

@implementation TI_BLE_DemoTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in TI-BLE-DemoTests");
}

@end
