//
//  TI_BLE_DemoTests.h
//  TI-BLE-DemoTests
//
//  Created by Ole Andreas Torvmark on 10/29/11.
//  Copyright (c) 2011 ST alliance AS. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface TI_BLE_DemoTests : SenTestCase

@end
